/******************************************************************************

ESTACIONAMENTO LINEAR

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N_MAX 10001
#define K_MAX 1001

typedef struct{
    int carros[K_MAX];
    int tam;
    int topo;
}TipoPilha;


int max(int A, int B){
    return ((A>B) ? (A):(B));
}

void inicializarPilha(TipoPilha *pilha){
    pilha->topo = -1; // pilha vazia
    pilha->tam = K_MAX;
    memset(pilha->carros, 0, K_MAX*sizeof(int));
}


int pilhaVazia(TipoPilha *pilha){
    if(pilha->topo == -1)
        return 1;
    return 0;
}

int pilhaCheia(TipoPilha *pilha){
    if(pilha->topo == pilha->tam-1)
        return 1;
    return 0;
}


int push(TipoPilha *pilha, int novo){
    int topo;
    if(pilhaCheia(pilha)) return 0;
    pilha->topo++;
    topo=pilha->topo;
    pilha->carros[topo] = novo;
    return 1;
    
}
//Em caso de sucesso, retorne 1. Caso contrário, retorne 0


int pop(TipoPilha *pilha){

    int topo;
    int item;
    item = -1;
    if(pilhaVazia(pilha)) return item;
    topo = pilha->topo;
    pilha->topo--;
    return pilha->carros[topo];
    

}


int main(){
    
    //Cria arrays de entrada e saida com zeros
    int chegada[N_MAX], saida[N_MAX];
    int carro, n, i=0, c, s, N, K, maior_tempo;
    TipoPilha fila;
    
    //Faz a leitura das entradas
    while(1){
        inicio:
        memset(chegada, 0, sizeof(chegada));
        memset(saida, 0, sizeof(saida));
        maior_tempo = 0;

        
        //Le entrada de N e K
        scanf("%d %d", &N, &K);
        if(N == 0 && K == 0) break;
        
        inicializarPilha(&fila);
        fila.tam = K+1;
        
        //Le entrada dos N carros com horario chegada(c) e saida(s)
        for(n=1; n<=N; n++){
            scanf("%d %d", &c, &s);
            chegada[c] = n;
            saida[s] = n;
            // le o maior tempo entres chegada e saida para usar no prox loop
            maior_tempo = max(max(maior_tempo, c), s);
            
        }
        
        fila.topo = 0;
        for(i=1; i<=maior_tempo; i++){

            //Testa se ha carro para sair
            if(saida[i] > 0){
                //Se carro para sair nao for ultimo da fila, break
               carro = pop(&fila);
               //printf("pop carro %d, fila.topo %d\n", carro,fila.carros[fila.topo]);
               if(saida[i] != carro){
                   //printf("fila.topo = %d\n", fila.topo);
                   //printf("Não e ultimo da fila i=%d\n", i);
                   printf("Nao\n");
                   goto inicio;
               }
            }

            //Testa se ha carro para chegar
            if(chegada[i] > 0){
                //Se não houver espaço na fila, break
                if(pilhaCheia(&fila)){
                    //printf("Não ha espaco na fila i=%d\n", i);
                    printf("Nao\n");
                    goto inicio;
                }
                else{
                    //printf("push %d\n", chegada[i]);
                    push(&fila, chegada[i]);
                }
                    
            }

            //printf("laco i=%d, fila.topo=%d\n", i, fila.carros[fila.topo]);
        }
        printf("Sim\n");
        
    }
    return 0;
}