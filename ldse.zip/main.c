/******************************************************************************

LISTA DINÂMICA SEQUENCIAL

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#define ALOCA_TAM 10 //aloca a cada 10

typedef struct{
    int chave;
    char nome[50];
    // outros componentes
}TipoItem;

typedef struct{
    TipoItem *itens;
    int ultimo;
    int tamanho;
}ListaLinearSD;

int inicializaLLSD(ListaLinearSD *lista){
    lista->ultimo = 0;
    lista->tamanho = ALOCA_TAM;
    lista->itens = malloc(ALOCA_TAM*sizeof(TipoItem));
    if(lista->itens == NULL) return -1;
    return 0;
}

void imprimeLLSD(ListaLinearSD *lista){
    int i=0;
    for(i=0; i<lista->ultimo; i++)
    printf("%d %s¥n",
    lista->itens[i].chave,lista->itens[i].nome);
}

int insereNoFinalLLSD(ListaLinearSD *lista, TipoItem novoItem){
    int pos = lista->ultimo, i;
    if(pos==lista->tamanho){
        TipoItem *aux = lista->itens; //guarda endereco antigo
        TipoItem *novaLista = malloc((lista->tamanho+ALOCA_TAM)
        *sizeof(TipoItem));
        if(novaLista == NULL) return -1;
        for(i=0; i<pos; i++)
            novaLista[i] = lista->itens[i];
        lista->itens = novaLista;
        lista->tamanho += ALOCA_TAM;
        if(aux!=NULL)
            free(aux); //libera memoria
    }
    lista->itens[pos] = novoItem;
    lista->ultimo++;
    return 0;
}

