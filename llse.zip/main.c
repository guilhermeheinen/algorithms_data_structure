/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

// Define max number of items
#define MAX 1000

// Create a struct type 'TipoItem'
typedef struct{
    int chave;
    char nome[50];
    // outros componentes
}TipoItem;

//Create a struct type ListaLinearSE
typedef struct{
    TipoItem itens[MAX];
    int ultimo;
}ListaLinearSE;


void inicializaListaLLSE(ListaLinearSE *lista){
    lista->ultimo= 0;
}


void imprimeListaLLSE(ListaLinearSE *lista){
    int i=0;
    for(i=0; i < lista->ultimo; i++)
        printf("%d %s\n",lista->itens[i].chave,lista->itens[i].nome);
}


int insereNoFinalLLSE(ListaLinearSE *lista, TipoItem novoItem){
    int pos = lista->ultimo;
    if(pos < MAX){
        lista->itens[pos] = novoItem;
        lista->ultimo++;
    }
    else return -1;
    return 0;
}

int buscaNomeLLSE(ListaLinearSE * lista, char nome[50]){
    int i=0;
    
    for(i=0; i < lista->ultimo; i++)
        if (strcmp(lista->itens[i].nome, nome) == 0)
            return lista->itens[i].chave;
    return -1;
}

int main()
{
    int i,n, chave;
    ListaLinearSE lista;
    TipoItem item;
    inicializaListaLLSE(&lista);
    scanf("%d",&n);
    for(i=0; i<n; i++)
    {
    scanf("%d %s",&item.chave,item.nome);
    if(insereNoFinalLLSE(&lista,item) < 0){
        printf("ERRO! Tamanho limite excedido.\n");
        break;
        }
    }
    chave = buscaNomeLLSE(&lista, "c");
    printf("chave c = %d\n", chave);
    //imprimeListaLLSE(&lista);
    return 0;
}

