/******************************************************************************

PILHA ESTÁTICA

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

#define MAX 10
typedef struct {
    int chave;
    char nome[51];
    //outros campos de item
}TipoItem;

typedef struct{
    TipoItem itens[MAX];
    int tam;
    int topo;
}TipoPilha;

void inicializarPilha(TipoPilha *pilha){
    pilha->topo = -1; // pilha vazia
    pilha->tam = MAX;
}


int pilhaVazia(TipoPilha *pilha){
    if(pilha->topo == -1)
        return 1;
    return 0;
}

int pilhaCheia(TipoPilha *pilha){
    if(pilha->topo == pilha->tam-1)
        return 1;
    return 0;
}


int push(TipoPilha *pilha, TipoItem novo){
/*
– Se a pilha estiver cheia, a inserção não é possível
– Atualiza o topo para uma posição acima (incremento)
– Insere um novo item no topo da pilha
*/
    int topo;
    if(pilhaCheia(pilha)) return 0;
    pilha->topo++;
    topo=pilha->topo;
    pilha->itens[topo] = novo;
    return 1;
    
}
//Em caso de sucesso, retorne 1. Caso contrário, retorne 0


TipoItem pop(TipoPilha *pilha){
/*
– Se a pilha estiver vazia, não é possível desempilhar
– Atualiza o topo para uma posição abaixo
(decremento)
– Pode retornar o item que estava no topo
*/

    int topo;
    TipoItem item;
    item.chave = -1;
    if(pilhaCheia(pilha)) return item;
    topo = pilha->topo;
    pilha->topo--;
    return pilha->itens[topo];
    

}
/*Em caso de sucesso, retorne o item que estava no topo. Caso
contrário, retorne um item com uma chave -1. 
*/
int main(){
    TipoPilha pilha;
    TipoItem item;
    int i,N;
    inicializarPilha(&pilha);
    scanf("%d",&N);
    //inserindo N itens na pilha
    for(i=0; i<N; i++){
        scanf("%d %s",&item.chave,item.nome);
        if(!push(&pilha,item)){
            break;
        }
    }
    //desempilhando
    while(!pilhaVazia(&pilha)){
        item = pop(&pilha);
        printf("Desempilha %d %s\n",item.chave,item.nome);
    }
    return 0;
}