/******************************************************************************

POSFIXA
O programa terá que lidar somente com operadores binários +,-,*,/,^, parênteses, letras e números.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N_MAX 1000
#define MAX_CARACTERES 300
#define TRUE 1
#define FALSE 0


typedef struct {
    int chave;
    char token;
    //outros campos de item
}TipoItem;

typedef struct{
    TipoItem itens[MAX_CARACTERES];
    int tam;
    int topo;
}TipoPilha;

typedef struct{
    char op;
    int precedencia;
    char associacao;
}TipoOperador;

//Define operadores, precedencia e associacao (e=esq., d=dir.)
TipoOperador operador[]={
    { .op='^', .precedencia=6, .associacao='d'},
    { .op='/', .precedencia=5, .associacao='e'},
    { .op='*', .precedencia=5, .associacao='e'},
    { .op='+', .precedencia=4, .associacao='e'},
    { .op='-', .precedencia=4, .associacao='e'},
    { .op='>', .precedencia=3, .associacao='e'},
    { .op='<', .precedencia=3, .associacao='e'},
    { .op='=', .precedencia=3, .associacao='e'},
    { .op='#', .precedencia=3, .associacao='e'},
    { .op='.', .precedencia=2, .associacao='e'},
    { .op='|', .precedencia=1, .associacao='e'}
};


void inicializarPilha(TipoPilha *pilha){
    pilha->topo = -1; // pilha vazia
    pilha->tam = MAX_CARACTERES;
    memset(pilha->itens, 0, sizeof(pilha->itens));
}


int pilhaVazia(TipoPilha *pilha){
    if(pilha->topo == -1)
        return 1;
    return 0;
}

int pilhaCheia(TipoPilha *pilha){
    if(pilha->topo == pilha->tam-1)
        return 1;
    return 0;
}


int push(TipoPilha *pilha, TipoItem novo){
    int topo;
    if(pilhaCheia(pilha)) return 0;
    pilha->topo++;
    topo=pilha->topo;
    pilha->itens[topo] = novo;
    return 1;
    
}


TipoItem pop(TipoPilha *pilha){

    int topo;
    TipoItem item;
    item.chave = -1;
    if(pilhaCheia(pilha)) return item;
    topo = pilha->topo;
    pilha->topo--;
    return pilha->itens[topo];
    

}

int getPrecedencia(char token){
    int i;
    for(i=0; i<11; i++)
        if(token == operador[i].op)
            return operador[i].precedencia;
    return 0;
}

char getAssociacao(char token){
    int i;
    for(i=0; i<11; i++)
        if(token == operador[i].op)
            return operador[i].associacao;
    return 0;
}

int isOperator(char token){
    int i;
    for(i=0; i<11; i++)
        if(token == operador[i].op)
            return 1;
    return 0;
}

int isLeftBracket(char token){
    if(token == '(')
        return 1;
    return 0;
}

int isRightBracket(char token){
    if(token == ')')
        return 1;
    return 0;
}

int isValid(char token){
    //valid ASCII carachters:
    //35; 40-57; 60-62;65-90;97-122;124
    
    if(token==35)
        return TRUE;
    
    if(token>= 40 && token<=57)
        return TRUE;
    
    if(token>= 60 && token<=62)
        return TRUE;
    
    if(token>= 65 && token<=90)
        return TRUE;
    
    if(token==94)
        return TRUE;
    
    if(token>= 97 && token<=122)
        return TRUE;
    
    if(token==124)
        return TRUE;
    
    return FALSE;
    
}

int isNumber(char token){
    if( !isOperator(token)      &&
        !isLeftBracket(token)   &&
        !isRightBracket(token))
        return 1;
    return 0;
}

int main(){

    TipoPilha pilhaEntrada, pilhaSaida, pilhaOperadores;
    char token, associacao;
    char expressaoEntrada[300]={}, expressaoSaida[300]={};
    TipoItem item, operadorTopo, in, out; 
    int count=0, flagPilhaOperadores = 1;
    int i, c, precedencia, N;
    int lexicalError;
    

    scanf("%d",&N);
    
    for(i=0;i<N;i++){
        inicializarPilha(&pilhaEntrada);
        inicializarPilha(&pilhaOperadores);
        inicializarPilha(&pilhaSaida);
 
        memset(expressaoEntrada, 0, sizeof(expressaoEntrada));
        memset(expressaoSaida, 0, sizeof(expressaoSaida));
        
        scanf("%s", expressaoEntrada);
        lexicalError = FALSE;
        
        for(c=strlen(expressaoEntrada)-1; c>=0; c--){
            in.chave = c;
            in.token = expressaoEntrada[c];
            push(&pilhaEntrada, in);
        }
        
        //Algoritmo Shunting-yard
        while(!pilhaVazia(&pilhaEntrada)){          //while there are tokens to be read
            count++;
            item = pop(&pilhaEntrada);             //read token
            
            if(!isValid(item.token))
                lexicalError = TRUE;    
            
            if(isNumber(item.token))                     //if token is a number:
                push(&pilhaSaida, item);           //push token to output queue

            if(isOperator(item.token)){                  
                //if token is a operator:
                //while there is an operator at the top of the operator
                //stack with greater than or equal to precedence 
                //and the operator is left associative:
                //pop operators from the operator stack, onto the output queue
                flagPilhaOperadores = 1;
                while(flagPilhaOperadores){
                    flagPilhaOperadores = 0;
                    if(!pilhaVazia(&pilhaOperadores)){
                        operadorTopo = pilhaOperadores.itens[pilhaOperadores.topo];
                        if(getPrecedencia(operadorTopo.token)>getPrecedencia(item.token)){
                            operadorTopo = pop(&pilhaOperadores);
                            push(&pilhaSaida, operadorTopo);
                            flagPilhaOperadores = 1;
                        }
                        else if((getPrecedencia(operadorTopo.token)==getPrecedencia(item.token)) && getAssociacao(item.token) == 'e'){
                            operadorTopo = pop(&pilhaOperadores);
                            push(&pilhaSaida, operadorTopo);
                            flagPilhaOperadores = 1;
                        }
                    }
                }
                
                push(&pilhaOperadores, item);      //push the read operator onto the operator stack
            }
            
            if(isLeftBracket(item.token)){               //if the token is a left bracket (i.e. "("), then:
                push(&pilhaOperadores, item);      //push it onto the operator stack
            }
            
            
            if(isRightBracket(item.token)){              //if the token is a right bracket (i.e. ")"), then:
                
                //while the operator at the top of the operator stack is not a left bracket:
			    //pop operators from the operator stack onto the output queue.
		        //pop the left bracket from the stack.
		        // if the stack runs out without finding a left bracket, then there are
		        //mismatched parentheses. 
                flagPilhaOperadores = 1;
                while(flagPilhaOperadores){
                    flagPilhaOperadores = 0;
                    if(!pilhaVazia(&pilhaOperadores)){
                        operadorTopo = pilhaOperadores.itens[pilhaOperadores.topo];
                        if(operadorTopo.token != '('){
                            operadorTopo = pop(&pilhaOperadores);
                            push(&pilhaSaida, operadorTopo);
                            flagPilhaOperadores = 1;
                        }
                    }
                }
                if(operadorTopo.token == '(')
                    pop(&pilhaOperadores);
            }
            
        }
        
    /*    
    if there are no more tokens to read:
	    while there are still operator tokens on the stack:
	        pop the operator onto the output queue.
    exit.
    */    
        while(!pilhaVazia(&pilhaOperadores)){
            push(&pilhaSaida, pop(&pilhaOperadores));
        }
        
        count = pilhaSaida.topo;
        for(c=count; c>=0; c--){
            expressaoSaida[c] = pop(&pilhaSaida).token;
        }
        
        if(lexicalError)
            printf("Lexical Error!\n");
        else
        printf("%s\n", expressaoSaida);
        
    }
    return 0;
}

