/******************************************************************************

1. A primeira linha é um número inteiro N (N ≤ 100.000)
2. Nas próximas N linhas é fornecida a sequência dos números na pilha
    2.1. o primeiro número é o topo da pilha
    2.2. o último número é base da pilha

3. Cada passo do procedimento consiste em:
 - remover do sorteio o primeiro número que está no topo da pilha
 - colocar o segundo número na base da pilha
 - repetir esse procedimento até sobrar apenas um número
 
Dada a sequência inicial dos números na pilha, determinar o número a ser contemplado no sorteio. 

Implementar FILA
- remocao no inicio
- insercao no final

*******************************************************************************/
#include <stdio.h>
#define N_MAX 100000


typedef struct{
    int chave;
    int num;
}TipoItem;

typedef struct{
    TipoItem vet[N_MAX];
    int inicio; //índice do primeiro elemento da fila
    int fim; //índice da posição seguinte ao último
    int tam; //tamanho do vetor (MAX)
    int qtd; //quantidade de elementos da fila
}TipoFilaSE;

void inicializaFilaSE(TipoFilaSE *fila){
    fila->inicio = 0;
    fila->fim = 0;
    fila->qtd = 0;
    fila->tam = N_MAX;
}


int filaVazia(TipoFilaSE *fila){
    if(fila->qtd == 0) return 1;
    return 0;
}

int filaCheia(TipoFilaSE *fila){
    if(fila->qtd == fila->tam) return 1;
    return 0;
}

int inserirFilaSE(TipoFilaSE *fila, TipoItem novo){
    // Sucesso retorna 1, caso contrário 0
    if(filaCheia(fila)) return 0;
    
    fila->vet[fila->fim].num = novo.num;
    fila->fim = (fila->fim + 1) % fila->tam;
    fila->qtd++;
    
    return 1;
}

TipoItem removerFilaSE(TipoFilaSE *fila){
    // Em caso de insucesso, retorna -1
    TipoItem aux;
    
    if(filaVazia(fila)){
        aux.num = -1;
        return aux;
    }
    
    aux = fila->vet[fila->inicio];
    fila->inicio = (fila->inicio+1) % fila->tam;
    fila->qtd--;
    return aux;
}



int main()
{
    TipoFilaSE fila;
    TipoItem item;
    int i,N,v,n;
    inicializaFilaSE(&fila);
    
    scanf("%d",&N);
    
    //Insere elementos na fila
    for(i=0; i<N; i++){
        scanf("%d",&n);
        item.chave = i;
        item.num = n;
        v = inserirFilaSE(&fila,item);
        //if(v==1)    printf("inseriu: %d\n", n);
    }
    
    //printf("Inicio = fila.qtd = %d\n", fila.qtd);
    
    while(fila.qtd > 1){
        removerFilaSE(&fila);
        item = removerFilaSE(&fila);
        inserirFilaSE(&fila, item);
    }
    
    item = removerFilaSE(&fila);
    printf("%d\n", item.num);
    //printf("Final = fila.qtd = %d\n", fila.qtd);
    
    return 0;
}


/*
int main()
{
    TipoFilaSE pilhaSorteio;
    TipoItem item;
    int i;
    int num, inseriu;
    
    inicializaFilaSE(&pilhaSorteio);
    printf("fim: %d, qtd: %d \n", pilhaSorteio.fim, pilhaSorteio.qtd);
    
    for(i=0; i<2; i++){
        scanf("%d", &num);
        item.chave = i;
        item.num = num;
        inseriu = inserirFilaSE(&pilhaSorteio, item);
        printf("fim: %d, qtd: %d, inseriu: %d \n", pilhaSorteio.fim, pilhaSorteio.qtd, inseriu);
    }
    
    for(i=0; i<2; i++){
        printf("%d\n", pilhaSorteio.vet[i].num);
        
    }
    
    
    return 0;
}






*/

