#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define M_MAX 1000000

//STRUCT declarations

typedef struct Name{
	char string[15];
	struct Name *nextName;
	struct Value *nextValue;
}Name;

typedef struct Value{
	int value;
	struct Value *nextValue;
}Value;

//Global variables
Name names[M_MAX];
int m = 1;
int b = 128;

//Functions
int hash(char *v){
	int h,i;
	for(h = 0, i=0; i<strlen(v); i++)
		h = (h*b + v[i]) % m;
	return h;
}

int isEmpty(int key){
	if(names[key].string[0] == 0)
		return 1;
	return 0;
	
}
int searchName(char* str){
	int key;
	key = hash(str);
	if(!isEmpty(key))
		return key;
	else
		return -1;
}

int insertNameAndValue(char *n, int v){
	int k;
	k = searchName(n);
	if(k != -1){
		strcpy(names[k].string, n);
		names[k].nextValue->value = v;
		//names[k].nextValue.nextValue = names[k].nextValue;
	}
	
	
}

int main(){
	char inputName[15];
	
	if(isEmpty(0))
		printf("empty\n");
	printf("%d", searchName("Ari"));

	return 0;
}
