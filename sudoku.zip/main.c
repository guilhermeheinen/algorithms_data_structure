/*
SUDOKU
*/

#include <stdio.h>
#include <stdlib.h>

#define TAMANHO 9

void main(){
    int testes,i,j,k,matriz[TAMANHO][TAMANHO],fatorial=1;
    int grupoX, grupoY;
    int *instancia;
    
    scanf("%d",&testes);
    instancia = malloc(testes*sizeof(int));
    
    for(i=0;i<testes;i++){
        
        // Recebe entradas e verifica linhas
        instancia[i] = 1;
        for(j=0;j<TAMANHO;j++){
            fatorial = 1;
            for(k=0;k<TAMANHO;k++){
                scanf("%d",&matriz[j][k]);
                fatorial *= matriz[j][k];
                
            }
            if(fatorial==362880)
                instancia[i]*=1;
            else
                instancia[i]=0;
        }
        
        // Verifica colunas
        for(k=0;k<TAMANHO;k++){
            fatorial = 1;
            for(j=0;j<TAMANHO;j++){
                fatorial *= matriz[j][k];
            }
            if(fatorial==362880)
                instancia[i]*=1;
            else
                instancia[i]=0;
        }

        // Verifica grupos
        for(grupoX=0; grupoX<6; grupoX+=3)
            for(grupoY=0; grupoY<6; grupoY+=3){
                fatorial = 1;
                for(j=0; j<3;j++){
                    for(k=0; k<3; k++)
                        fatorial *= matriz[grupoX+j][grupoY+k];
                }
                if(fatorial==362880)
                    instancia[i]*=1;
                else
                    instancia[i]=0;
            }
        
            
        if(instancia[i]==1){
            printf("Instancia %d\nSIM\n\n", i+1);
        }else{
            printf("Instancia %d\nNAO\n\n", i+1);
        }
    }
}