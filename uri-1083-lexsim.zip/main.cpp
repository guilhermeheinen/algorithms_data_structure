/*
Cheguei a um código parecido com esse utilizando o algoritmo Shunting Yard de Djkistra, mas tive
dificuldades em implementar o erro de sintaxe.

O codigo abaixo foi retirado de:

https://github.com/leonardofalk/URI-Homework/blob/master/Algoritmos%20II/2063%20-%20Pilha%20II/1083%20-%20LEXSIM%20-%20Avaliador%20L%C3%A9xico%20e%20Sint%C3%A1tico.cpp

O codigo abaixo utiliza tambem o algoritmo de Shunting Yard utilizando uma pilha para converter a expressao
de INFIXA para POSFIXA e para verificar erro lexico e de sintaxe.

A verificação de sintaxe é feita no momento de inserir os caracteres na pilha e depois da string posfixa pronta,
e feita uma nova verificacao de sintaxe.

*/


#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <stack>
#include <map>
 
using namespace std;
 
int main(){
    map<char, int> prioridade;
    prioridade['^'] = 6;
    prioridade['*'] = 5;
    prioridade['/'] = 5;
    prioridade['+'] = 4;
    prioridade['-'] = 4;
    prioridade['>'] = 3;
    prioridade['<'] = 3;
    prioridade['='] = 3;
    prioridade['#'] = 3;
    prioridade['.'] = 2;
    prioridade['|'] = 1;
    prioridade['('] = 0;
 
    string exp;
 
    //Executa o laco para cada linha de entrada
    while(getline(cin, exp)){
        stack<char> s;
        string pos = "";        //expressao de saida poxfixa
        bool lexi_error = false;
        bool sint_error = false;
 
        for(int i=0; exp[i]!='\0'; i++){
            char ch = exp[i];

            /*Testa 4 condições:
            1. O caractere e alfanumerico
            2. O caractere e '('
            3. O caractere e ')'
            4. O caractere e um simbolo
            */
            
            if(isalnum(ch)){
                if(i == 0 or !isalnum(exp[i-1])){
                    pos += ch;
                } 
                else {
                    sint_error = true;
                    break;
                }
            } 
            
            else if(ch == '('){
                s.push(ch);
            }
            
            else if(ch == ')'){
                while(!s.empty() and s.top() != '('){
                    pos += s.top();
                    s.pop();
                }
 
                if(!s.empty()){
                    s.pop();
                }
                else {
                    sint_error = true;
                    break;
                }
            } 
            
            else if(prioridade.count(ch)){
                while(!s.empty() and prioridade[s.top()] >= prioridade[ch]){
                    pos += s.top();
                    s.pop();
                }
 
                s.push(ch);
            }
            
            else {
                lexi_error = true;
                break;
            }
        }
 
        while(!s.empty() and s.top() != '('){
            pos += s.top();
            s.pop();
        }
 
        if(!s.empty()){
            sint_error = true;
        }
 
        stack<string> valid;
 
        if(!lexi_error and !sint_error){
            pos += '\0';
 
            for(int i=0; pos[i]!='\0'; i++){
                char ch = pos[i];
 
                if(isalnum(ch)){
                    string temp = "" + ch;
                    valid.push(temp);
                }
                else {
                    string var1, var2;
 
                    if(!valid.empty()){
                        var2 = valid.top();
                        valid.pop();
                    }
                    else {
                        sint_error = true;
                        break;
                    }
 
                    if(!valid.empty()){
                        var1 = valid.top();
                        valid.pop();
                    }
                    else {
                        sint_error = true;
                        break;
                    }
 
                    valid.push(var1 + ch + var2);
                }
            }
 
            if(valid.size() != 1){
                sint_error = true;
            }
        }
 
        if(lexi_error){
            printf("Lexical Error!\n");
 
        }
        else if(sint_error){
            printf("Syntax Error!\n");
 
        }
        else {
            printf("%s\n", pos.c_str());
        }
    }
    
    return 0;
}