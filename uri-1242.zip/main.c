/******************************************************************************

URI 1242

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 310
typedef struct {
    int chave;
    char c;
    //outros campos de item
}TipoItem;

typedef struct{
    TipoItem itens[MAX];
    int tam;
    int topo;
}TipoPilha;


char *ligacao[] = {
    "BS",
    "SB",
    "CF",
    "FC"
};

void inicializarPilha(TipoPilha *pilha){
    pilha->topo = -1; // pilha vazia
    pilha->tam = MAX;
    memset(pilha->itens, "", MAX);
}


int pilhaVazia(TipoPilha *pilha){
    if(pilha->topo == -1)
        return 1;
    return 0;
}

int pilhaCheia(TipoPilha *pilha){
    if(pilha->topo == pilha->tam-1)
        return 1;
    return 0;
}


int push(TipoPilha *pilha, TipoItem novo){
/*
– Se a pilha estiver cheia, a inserção não é possível
– Atualiza o topo para uma posição acima (incremento)
– Insere um novo item no topo da pilha
*/
    int topo;
    if(pilhaCheia(pilha)) return 0;
    pilha->topo++;
    topo=pilha->topo;
    pilha->itens[topo] = novo;
    return 1;
    
}
//Em caso de sucesso, retorne 1. Caso contrário, retorne 0


TipoItem pop(TipoPilha *pilha){
/*
– Se a pilha estiver vazia, não é possível desempilhar
– Atualiza o topo para uma posição abaixo
(decremento)
– Pode retornar o item que estava no topo
*/

    int topo;
    TipoItem item;
    item.chave = -1;
    if(pilhaCheia(pilha)) return item;
    topo = pilha->topo;
    pilha->topo--;
    return pilha->itens[topo];
    

}

int verificaLigacao(TipoPilha *pilha){
    int i;
    char str[2];
    
    //printf("%d\n", pilha->topo);
    if(pilha->topo >= 1){
        str[0] = pilha->itens[pilha->topo-1].c;
        str[1] = pilha->itens[pilha->topo].c;
        
        for(i=0; i<4; i++)
            if(memcmp(str, ligacao[i], 2)==0)
                return 1;
    }
    return 0;
}

int main(){
    TipoPilha pilha;
    TipoItem item;
    int i, num, dobra;
    char input[MAX];

    while(gets(input)){
        inicializarPilha(&pilha);
        num = 0;
        for(i=0; i< strlen(input); i++){
            item.chave = i;
            item.c = input[i];
            push(&pilha, item);
            dobra = verificaLigacao(&pilha);
            if(dobra){
                pop(&pilha);
                pop(&pilha);
                num++;
            }
        }
        printf("%d\n", num);
    }
    return 0;
}
