
/*
Entrada:
A primeira linha contém um inteiro N, indicando o número de casos de teste a seguir.

Cada caso de teste inicia com um inteiro M (1 ≤ M ≤ 1000), indicando o número de alunos.
Em seguida haverá M inteiros distintos Pi (1 ≤ Pi ≤ 1000), onde o i-ésimo inteiro indica a nota do i-ésimo aluno.

Os inteiros acima são dados em ordem de chegada, ou seja, o primeiro inteiro diz respeito ao primeiro aluno a chegar na fila, 
o segundo inteiro diz respeito ao segundo aluno, e assim sucessivamente.

Saída:
Para cada caso de teste imprima uma linha, contendo um inteiro, indicando o número de alunos que não precisaram trocar de lugar
mesmo após a fila ser reordenada.

Solução:
Optei por utilizar o algoritmo de counting sort, devido a complexicade O(n) e por possibilitar a contagem de trocas.

*/
 
 
#include <stdio.h>
#include <string.h>
#define M_MAX 1010

int a[M_MAX]; //vetor de entrada
int b[M_MAX]; //vetor ordenado
int c[M_MAX]; //vetor auxiliar

int countingSort(int n,int k)
{
     
     memset(c, 0, sizeof c);
     int i,j, index=0, notRepositioned=0;
     
     for(i=0;i<n;++i)
      c[a[i]]=c[a[i]]+1;//count contem o numero de elementos iguais a i
     
     for(i=k;i>=0;--i)
      for(j=c[i];j>=1;--j){
       b[index] = i;
       index++;
      }
      
     for(i=0; i<index; i++)
        if(a[i] == b[i])
            notRepositioned++;
     
     return notRepositioned;
}
 
int main()
{
    int caso, casos, n, i, k=0, notReplaced;
    
    scanf("%d", &casos); // numero de casos
    for(caso=0; caso<casos; caso++){
        
    
        scanf("%d",&n);
        
        memset(a, 0, sizeof a); 
        memset(b, 0, sizeof b); 
        
        for(i=0;i<n;++i)
        {
         scanf("%d",&a[i]);
         if(a[i]>k)
          k=a[i];
        }
        notReplaced = countingSort(n,k); 
        printf("%d\n", notReplaced);
        
    }
    return 0;
}