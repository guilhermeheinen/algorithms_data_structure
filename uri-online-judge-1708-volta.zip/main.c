/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

/*
Exercicio:
Dados os tempos que o piloto mais rápido e o piloto mais lento levam
para completar uma volta, determinar em que volta o último colocado se
tornará um retardatário, ou seja, será ultrapassado pelo líder.

INPUT:
A linha da entrada contém dois números inteiros X e Y (1 ≤ X < Y ≤ 10000),
os tempos, em segundos, que o piloto mais rápido e o piloto mais lento levam
para completar uma volta

OUTPUT:
Produzir uma única linha, contendo um único inteiro: a volta em que o piloto
mais lento se tornará um retardatário

*/

int main()
{
    int x, y, r;
    scanf("%d %d", &x, &y);
    r = (y-1)/(y-x)+1;
    printf("%d", r);
}