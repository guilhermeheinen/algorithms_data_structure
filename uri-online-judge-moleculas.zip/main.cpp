#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define clean(x, v) memset((x), (v), sizeof(x))

typedef vector<int> vi;
const int N = 1e4+5;
int n, a, b;

vi adj[2][N];
int visitado[N], pai[N], sTreeSize[N];
vi centr[2];

map<map<int, int>, int> m;

void dfscentr(int t, int u) {
  visitado[u] = 1;
  sTreeSize[u] = 1;

  int ok = 1;
  for (int v : adj[t][u]) {
    if (v == pai[u]) continue;
    if (!visitado[v]) pai[v]=u, dfscentr(t, v);
    sTreeSize[u] += sTreeSize[v];
    if (sTreeSize[v] > n/2) ok=0;
  }
  if (n-sTreeSize[u] > n/2) ok=0;
  if (ok) centr[t].pb(u);
}

int dfs(int t, int u) {
  visitado[u]=1;
  map<int, int> c;
  for (int v : adj[t][u]) {
    if (v == pai[u]) continue;
    if (!visitado[v]) pai[v]=u, dfs(t, v);
    c[sTreeSize[v]]++;
  }

  if (!m.count(c)) m[c] = m.size();
  return sTreeSize[u]=m[c];
}

int main() {
  while (~scanf("%d", &n)) {
    m.clear();
    centr[0].clear(), centr[1].clear();
    for (int i = 0; i <= n; ++i) adj[0][i].clear(), adj[1][i].clear();

    for (int i = 0; i < n-1; ++i) scanf("%d%d", &a, &b), adj[0][a].pb(b), adj[0][b].pb(a);
    for (int i = 0; i < n-1; ++i) scanf("%d%d", &a, &b), adj[1][a].pb(b), adj[1][b].pb(a);

    clean(visitado,0);
    pai[1] = -1;
    dfscentr(0, 1);

    clean(visitado,0);
    pai[1] = -1;
    dfscentr(1, 1);

    clean(visitado,0);
    pai[centr[1][0]] = -1;
    int en = dfs(1, centr[1][0]);

    clean(visitado,0);
    pai[centr[0][0]] = -1;
    int eq = dfs(0, centr[0][0]) == en;
    if (!eq and centr[0].size()>1) {
      clean(visitado,0);
      pai[centr[0][1]]=-1;
      eq = dfs(0, centr[0][1]) == en;
    }

    printf("%c\n", eq?'S':'N');
  }

  return 0;
}